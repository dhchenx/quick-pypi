
def say_quick_hi(name):
    print("Hi, "+name)