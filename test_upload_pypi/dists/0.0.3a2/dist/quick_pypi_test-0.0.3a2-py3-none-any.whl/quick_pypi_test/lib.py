
def say_quick_hi(name):
    print("Hi, "+name)

if __name__=="main":
    print("we are in main()!")