# A quick-pypi-test package!

This is a quick-pypi-test package!

## Installation
```pip
pip install quick-pypi-test==0.0.3a1
```

## License
This project follows the MIT license.
