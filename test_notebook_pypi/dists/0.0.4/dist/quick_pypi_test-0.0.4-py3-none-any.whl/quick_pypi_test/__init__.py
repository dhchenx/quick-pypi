__all__=["lib"]

def hello_world():
    print("hello world!")