import fastnbs
from quick_pypi_test.lib import *
say_hi()